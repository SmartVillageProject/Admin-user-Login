package com.nblk.klu.villagerevolution;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MostImportantCommoditiesManufactured extends AppCompatActivity {

    EditText c1,c2,c3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_most_important_commodities_manufactured);

        c1=findViewById(R.id.income);
        c2=findViewById(R.id.mic2);
        c3=findViewById(R.id.mic3);

    }
    public void gotoList(View view) {
        String mic1,mic2,mic3;
        mic1=" "+c1.getText().toString();
        mic2=" "+c2.getText().toString();
        mic3=" "+c3.getText().toString();

        Intent i=new Intent(this,ListOfDomains.class);
        startActivity(i);
    }

    public void resetAll(View view) {

        c1.setText("");
        c2.setText("");
        c3.setText("");
    }

    public void goBack(View view) {
        Intent i=new Intent(this,ListOfDomains.class);
        startActivity(i);

    }
}
