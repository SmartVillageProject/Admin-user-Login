package com.nblk.klu.villagerevolution;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class UserActivity extends AppCompatActivity {

    EditText state, dist,mandal,panchayat,village;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);

        state = findViewById(R.id.statedown);
        dist = findViewById(R.id.districtdown);
        mandal=findViewById(R.id.mandal);
        panchayat=findViewById(R.id.panchayat);
        village=findViewById(R.id.village);

    }

    public void gotoList(View view) {

        String s=state.getText().toString();
        String d=dist.getText().toString();
        String m=mandal.getText().toString();
        String p=panchayat.getText().toString();
        String v=village.getText().toString();

        Intent i = new Intent(UserActivity.this, ListOfDomains.class);
        startActivity(i);
    }
}

