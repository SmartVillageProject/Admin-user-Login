package com.nblk.klu.villagerevolution;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class ApproachtoVillage extends AppCompatActivity {
    EditText pav_roads,mud_roads,f_path,nav_riv,nav_can,nav_wat,nr_town;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_approachto_village);
        pav_roads=findViewById(R.id.pav_road);
        mud_roads=findViewById(R.id.mud_road);
        f_path=findViewById(R.id.foot_path);
        nav_riv=findViewById(R.id.nav_river);
        nav_can=findViewById(R.id.nav_canal);
        nav_wat=findViewById(R.id.other_path);
        nr_town=findViewById(R.id.near_town);

    }
    public void gotoList(View view) {
        long pave_roads,muddy_roads,foot_paths,na_riv,na_can,na_wat,near_town;
        pave_roads=Long.parseLong("0"+pav_roads.getText().toString());
        muddy_roads=Long.parseLong("0"+mud_roads.getText().toString());
        foot_paths=Long.parseLong("0"+f_path.getText().toString());
        na_riv=Long.parseLong("0"+nav_riv.getText().toString());
        na_can=Long.parseLong("0"+nav_can.getText().toString());
        near_town=Long.parseLong("0"+nr_town.getText().toString());
        na_wat=Long.parseLong("0"+nav_wat.getText().toString());
        Intent i=new Intent(this,ListOfDomains.class);
        startActivity(i);

    }

    public void goBack(View view) {
        Intent back=new Intent(this, ListOfDomains.class);
        startActivity(back);
    }

    public void resetAll(View view) {
        pav_roads.setText("");
        mud_roads.setText("");
        f_path.setText("");
        nav_riv.setText("");
        nav_can.setText("");
        nav_wat.setText("");
        nr_town.setText("");

    }
}