package com.nblk.klu.villagerevolution;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioGroup;

public class CreditSocieties extends AppCompatActivity {
    EditText agricre,nagricre,wshg,mshg,mixshg;
    RadioGroup r,r1,r2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_credit_societies);
        agricre=findViewById(R.id.cresoc);
        nagricre=findViewById(R.id.cresoc2);
        wshg=findViewById(R.id.womensfg);
        mshg=findViewById(R.id.mensfg);
        mixshg=findViewById(R.id.mixsfg);
        r=findViewById(R.id.cre);
        r1=findViewById(R.id.creavail);
        r2=findViewById(R.id.noncre);

    }
    public void gotoList(View view) {
        long agricredits,nagricredits,womenshg,menshg,mixedshg;
        int chooseID,chooseID1,chooseID2;
        agricredits=Long.parseLong("0"+agricre.getText().toString());
        nagricredits=Long.parseLong("0"+nagricre.getText().toString());
        womenshg=Long.parseLong("0"+wshg.getText().toString());
        menshg=Long.parseLong("0"+mixshg.getText().toString());
        chooseID=r.getCheckedRadioButtonId();
        chooseID1=r1.getCheckedRadioButtonId();
        chooseID2=r2.getCheckedRadioButtonId();
        switch (chooseID) {
            case R.id.creyes:
                break;
            case R.id.creno:
                break;
        }
        switch (chooseID1) {
            case R.id.creavailyes:
                break;
            case R.id.creavailno:
                break;
        }
        switch (chooseID2){
            case R.id.noncreyes:
                break;
            case R.id.noncreno:
                break;

        }
        Intent i=new Intent(this,ListOfDomains.class);
        startActivity(i);

    }

    public void goBack(View view) {
        Intent back=new Intent(this, ListOfDomains.class);
        startActivity(back);
    }

    public void resetAll(View view) {
        agricre.setText("");
        nagricre.setText("");
        wshg.setText("");
        mshg.setText("");
        mixshg.setText("");
        r.clearCheck();
        r1.clearCheck();
        r2.clearCheck();
    }
}