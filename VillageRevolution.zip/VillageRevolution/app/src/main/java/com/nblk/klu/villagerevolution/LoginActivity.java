package com.nblk.klu.villagerevolution;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class LoginActivity extends AppCompatActivity {

    EditText user,pass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        user=findViewById(R.id.username);
        pass=findViewById(R.id.password);


    }

    public void validate(View view) {
        String u=user.getText().toString();
        String p=pass.getText().toString();

        if (u.equals("admin")&&p.equals("admin")){
            Intent i=new Intent(this,AdminActivity.class);
            startActivity(i);
        }
        else{
            if (u.equals("user")&&p.equals("user")){
                Intent i=new Intent(this,UserActivity.class);
                startActivity(i);
            }
        }
    }

    public void gotoChoose(View view) {
        Intent i=new Intent(this,ChooseActivity.class);
        startActivity(i);
    }
}
