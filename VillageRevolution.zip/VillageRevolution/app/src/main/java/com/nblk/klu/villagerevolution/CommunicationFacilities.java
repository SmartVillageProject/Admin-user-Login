package com.nblk.klu.villagerevolution;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioGroup;

public class CommunicationFacilities extends AppCompatActivity {
    RadioGroup rg,rg1,rg2,rg3,rg4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_communication_facilities);
        rg=(RadioGroup)findViewById(R.id.radioGroup);
        rg1=(RadioGroup)findViewById(R.id.radioGroup2);
        rg2=(RadioGroup)findViewById(R.id.radioGroup3);
        rg3=(RadioGroup)findViewById(R.id.radioGroup4);
        rg4=(RadioGroup)findViewById(R.id.radioGroup5);
    }
    public void gotoList(View view) {
        int choosenId=rg.getCheckedRadioButtonId();
        switch(choosenId)
        {
            case R.id.busyes:
                break;
            case R.id.busno:
                break;
        }
        int choosenId1=rg1.getCheckedRadioButtonId();
        switch(choosenId1)
        {
            case R.id.naviyes:
                break;
            case R.id.navino:
                break;
        }
        int choosenId2=rg2.getCheckedRadioButtonId();
        switch(choosenId2)
        {
            case R.id.railyes:
                break;
            case R.id.railno:
                break;
        }
        int choosenId3=rg3.getCheckedRadioButtonId();
        switch(choosenId3)
        {
            case R.id.railavailyes:
                break;
            case R.id.railavailno:
                break;
        }
        int choosenId4=rg4.getCheckedRadioButtonId();
        switch(choosenId4)
        {
            case R.id.naviwyes:
                break;
            case R.id.naviwno:
                break;
        }

        Intent i=new Intent(this,ListOfDomains.class);
        startActivity(i);

    }

    public void resetAll(View view) {
        rg.clearCheck();
        rg1.clearCheck();
        rg2.clearCheck();
        rg3.clearCheck();
        rg4.clearCheck();




    }
    public void goBack(View view) {
        Intent i=new Intent(this,ListOfDomains.class);
        startActivity(i);

    }
}
